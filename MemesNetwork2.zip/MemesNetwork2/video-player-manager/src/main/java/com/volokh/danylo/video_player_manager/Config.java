package com.volokh.danylo.video_player_manager;

public class Config {

    public static final boolean SHOW_LOGS = true;

}
