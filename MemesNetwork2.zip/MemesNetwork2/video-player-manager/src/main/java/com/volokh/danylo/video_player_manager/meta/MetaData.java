package com.volokh.danylo.video_player_manager.meta;

public interface MetaData {

}
