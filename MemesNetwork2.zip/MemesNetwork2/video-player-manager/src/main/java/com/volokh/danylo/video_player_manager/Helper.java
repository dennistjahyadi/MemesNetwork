package com.volokh.danylo.video_player_manager;

import android.content.res.AssetFileDescriptor;

import java.util.List;

public class Helper {
    public static List<AssetFileDescriptor> videoCache;
}
